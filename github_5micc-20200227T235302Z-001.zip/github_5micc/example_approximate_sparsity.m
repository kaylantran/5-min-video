clear all;
clc;
% example of beamspace- shows approximate sparsity
H=reshape(dlmread(strcat('it_',num2str(43),'time_dom_channel.txt')),[64,64]);
H=H(1:32,1:32);
figure()
[xx,yy]=meshgrid([1:32],[1:32]);
surf(abs(fft2(H)/32),'EdgeColor','none')
view([0,90])
xlim([1,32])
ylim([1,32])
colormap(flipud(hot))
grid off
colorbar
xlab=xlabel('Beamspace columns ','Interpreter','Latex')
set(xlab,'FontSize',14);
ylab=ylabel('Beamspace rows','Interpreter','Latex');
set(ylab,'FontSize',14);
set(gca,'fontsize',14);
