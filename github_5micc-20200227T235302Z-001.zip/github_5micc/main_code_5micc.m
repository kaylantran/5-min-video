% If you use this code, please cite 
% [1] N. J. Myers, A. Mezghani, and R. W. Heath Jr., "FALP: Fast beam alignment in mmWave systems with low-resolution phase shifters",
% IEEE Transactions on Communications, 2019.
% The ideas in this code are based on zero filling-based beam alignment technique discussed in [1]
clear all;
clc;
addpath('channel_data_20MHz_NB_38GHz_64_64/')
prob_vec=[];            %Stores probability for dirac sensing/ antenna switching
prob_vec_P=[];          %Stores probability for random 2D-circulant sensing using perfect binary array


sigma=1;                % noise standard devn.
N=32;                   % NxN antenna array
Nrandom=5;             % Number of random circulant shift configurations for each Meas, Used 30 in simulations
Nchannel=100;           
D=zeros(N,N);
D(1,1)=1;               % Dirac matrix
Measvec=[2:5:40,40:5:80]; % Number of channel measurements
for i=Measvec
    success=0;          % Count to measure probability
    for ch=1:1:Nchannel
        H=reshape(dlmread(strcat('it_',num2str(ch),'time_dom_channel.txt')),[64,64]); 
        H=H(1:32,1:32);                     % load 32x32 channel matrix
        X=fft2(H)/N;                        % beamspace matrix 
        [~,indorig]=max(abs(X(:)));         % find location where beamspace is maximum-> best beam with 2ddft exh. search 
        vec_x=X(:);                         % vector version of beamspace
        for j=1:1:Nrandom
            M=i;
            Hzf=zeros(N,N);                 % Construct subsampled channel
            indices=randsample(N^2,M);      % which antennas to turn on (M distinct random integers from 1 to N^2)
            for mm=1:1:M
                [r,c]=ind2sub([N,N],indices(mm));       % 2D- coordinate of the indices, Here r,c start from 1.
                noise=sigma*(randn + 1j*randn)/sqrt(2);
                Dshift=circshift(D,[r-1,c-1]);          % Calculate 2D-circulant shift of D
                Hzf(r,c)=(H(:).'*conj(Dshift(:)))+noise;    % <H,F>, where F is shifted Dirac matrix.
            end            
            Xest=fft2(Hzf);                                 % Estimated beamspace
            [~,indest]=max(abs(Xest(:)));                   
            BFloss_curr=20*log10(abs(vec_x(indorig)/vec_x(indest))); % calculate beamforming loss
            if BFloss_curr<1 %indorig==indest                   % if beamforming loss is less than 1dB, successful beamalignment
                success=success+1;
            end
        end
    end
prob_vec=[prob_vec,success/(Nchannel*Nrandom)];    
end

% Same code as above- just replace Dirac matrix with a perfect binary array
P=dlmread('PBA_32x32.txt');  % load perfect binary array, check out abs(fft2(P))- this will be a constant magnitude matrix!
for i=Measvec
    successP=0;
    for ch=1:1:Nchannel
        H=reshape(dlmread(strcat('it_',num2str(ch),'time_dom_channel.txt')),[64,64]);
        H=H(1:32,1:32);
        X=fft2(H)/N;
        [~,indorig]=max(abs(X(:)));
        vec_x=X(:);
        for j=1:1:Nrandom
            M=i;
            G=zeros(N,N);
            indices=randsample(N^2,M);  % which ones to switch
            for mm=1:1:M
                [r,c]=ind2sub([N,N],indices(mm));
                noise=sigma*(randn + 1j*randn)/sqrt(2);
                Pshift=circshift(P,[r-1,c-1]);
                G(r,c)=(H(:).'*conj(Pshift(:)))+noise;          % This is the G defined in the presentation
            end            
            Sest=fft2(G);
            [~,indest]=max(abs(Sest(:)));
            BFloss_curr=20*log10(abs(vec_x(indorig)/vec_x(indest)));
           if BFloss_curr<1 %indorig==indest
                successP=successP+1;
            end
        end
    end
prob_vec_P=[prob_vec_P,successP/(Nchannel*Nrandom)];    
end

%%

figure()
hold on
p=plot(Measvec, prob_vec_P,'color',[0 0.5 0], 'LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','c')
p.Marker='d';
plot(Measvec, prob_vec,'bo-', 'LineWidth',2,'MarkerSize',10,'MarkerEdgeColor','k','MarkerFaceColor','y')
%dlmwrite('PBA_meas_prob.txt',[Measvec.',prob.'])
xlab= xlabel('Number of channel measurements ($$M$$) ','Interpreter','Latex');
set(xlab,'FontSize',14);
ylab=ylabel('Probability of succesful beam alignment','Interpreter','Latex');
set(ylab,'FontSize',14);
set(gca,'fontsize',14);
xlim([2,80])
h_legend=legend('Circulant sensing with a PBA','Random antenna switching', 'Location', 'SouthEast');
set(h_legend,'Interpreter','Latex','FontSize',14);
hold off





