Codes for ICASSP 5minute video contest submission

“Fast beam alignment in millimeter wave radios”
By Juliet M. Leger, Kayla N. Tran, and Frida K. Maldonado.
[Undergraduate students at The University of Texas at Austin]

Tutor: Nitin Jonathan Myers           [Graduate student in ECE]
Supervisor: Prof. Robert W. Heath Jr. [Cockrell Family Chair Professor in ECE]


1) To reproduce the Probability vs channel measurements plot, run main_code_5micc.m
2) To check approximate sparsity of beamspace channel, run example_approximate_sparsity.m

If you use this code, please cite
[1] N. J. Myers, A. Mezghani, and R. W. Heath Jr., "FALP: Fast beam alignment in mmWave systems with low-resolution phase shifters", IEEE Transactions on Communications, 2019.

For more details on this research, visit
www.profheath.org    (or)
https://sites.google.com/site/nitinmyers/home